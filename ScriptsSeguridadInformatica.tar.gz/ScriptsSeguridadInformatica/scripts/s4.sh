#!/bin/bash
if [ $# != 1 ]
then
	echo "Introduce un usuario"
else
	echo "Usuario eliminado"
	sudo userdel $1
  fi

