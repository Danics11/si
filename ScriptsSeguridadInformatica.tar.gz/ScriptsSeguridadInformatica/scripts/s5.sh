#!/bin/bash/

if [ $# != 1 ]
then
	echo "Introduce el nombre del directorio "
else
echo "Carpeta creada"
mkdir $1 
 chmod 777 $1

fi
