#!/bin/bash
while read -r linea
do
	echo " $linea"
done < "Lineas.txt"


