#!/bin/bash
for VAR in $*
do
if [ -f $VAR ]
then
  more $VAR
else
  echo No existe $VAR
fi
done
