#!/bin/bash/
if [ -f $1 ]
then
		ls -l -1 $1
fi



